hello <- "hello world"
print(hello)

planilha <- read.csv("dadosLista1.csv")
print (planilha)